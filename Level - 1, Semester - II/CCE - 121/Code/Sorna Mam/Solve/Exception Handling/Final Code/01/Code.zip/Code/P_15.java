/*
(Catching Exceptions Using Outer Scopes) Write a program showing that a method with 
its own try block does not have to catch every possible error generated within the try. 
Some exceptions can slip through to, and be handled in, other scopes.
*/

public class P_15 {

    public static void method_15(){
        try{
            System.out.println("Inside the methods.");
            // ArithmeticException handled locally
            int a = 10/0;
        } catch(ArithmeticException e){
            System.out.println("Caught ArithmeticException inside someMethod: " + e);

            // This exception is NOT caught here
            String str = null;
            System.out.println(str.length());  // NullPointerException will slip out
        }
    }

    public static void main(String[] args) {
        try{
            method_15();
        } catch(NullPointerException e){
            System.out.println("Caught NullPointerException in main: " + e);
        }
        System.out.println("Program continues after handling exception in main.");
    }
}
