
import java.util.Scanner;



public class Main {

    // Method to add numbers and throw exception if duplicate found


    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("ENtere");
        sc.hasNextInt();
        int n = sc.nextInt();
        System.out.println("Number "   + "   " + n);
        sc.close();
    }
}
